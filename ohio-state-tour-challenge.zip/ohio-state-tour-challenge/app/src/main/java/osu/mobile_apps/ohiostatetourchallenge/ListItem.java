package osu.mobile_apps.ohiostatetourchallenge;

class ListItem {

    private String head;
    private String desc;

    ListItem(String head, String desc){
        this.head = head;
        this.desc = desc;
    }

    String getHead(){
        return head;
    }

    String getDesc(){
        return desc;
    }


}
